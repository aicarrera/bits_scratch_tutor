"""Core configuration helpers."""
