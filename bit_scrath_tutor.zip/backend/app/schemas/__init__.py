"""Pydantic DTOs."""
